import React from 'react'

const Layout = ({ children }) => (
  <div className="App">
    {children}
  </div>
);

export default Layout;